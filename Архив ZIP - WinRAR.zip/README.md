<div align="center"> <h1> Portfolio- Website</h1>
<p>A personal portfolio website built with HTML, CSS, and JavaScript to make Open Source accessible to newcomers.</p></div>

## Demo
![portfolio](https://user-images.githubusercontent.com/107752425/192083103-e773c142-6ed0-4223-8fca-62525c2f908a.png)

## Chat with me

Want to chat with me? Join my discord server from below badge.

[![Join now - Discord](https://img.shields.io/badge/Join_now-Discord-2ea44f?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/CapGk4dEaV)

------

<div align="center">
<h3>Don't forget to ⭐ this repo</h3>
</div>
